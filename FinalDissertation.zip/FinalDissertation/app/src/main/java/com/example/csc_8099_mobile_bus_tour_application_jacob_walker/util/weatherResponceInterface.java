package com.example.csc_8099_mobile_bus_tour_application_jacob_walker.util;

//originally used for testing purposes
//not used in code at the moment, but kept in as the developer wishes to advance the project
//upon completetion of the task and will be useful to incorporate mutex's in the future
//acts in much the same as Retrofit call class

public interface weatherResponceInterface {

    public void OnWeatherResponce();
}
